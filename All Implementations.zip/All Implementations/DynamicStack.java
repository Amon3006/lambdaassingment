public class DynamicStack {

    private int[] arr;
    private int top;
    private int capacity;

    // Constructor
    public DynamicStack(int initialSize) {
        arr = new int[initialSize];
        capacity = initialSize;
        top = -1;
    }

    // ================= BASIC =================

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == capacity - 1;
    }

    public int size() {
        return top + 1;
    }

    // ================= RESIZE METHODS =================

    private void resize() {
        int newCapacity = capacity * 2;
        int[] newArr = new int[newCapacity];

        for (int i = 0; i <= top; i++) {
            newArr[i] = arr[i];
        }

        arr = newArr;
        capacity = newCapacity;
    }

    // Optional: shrink array
    private void shrink() {
        if (capacity <= 1) return;

        int newCapacity = capacity / 2;
        int[] newArr = new int[newCapacity];

        for (int i = 0; i <= top; i++) {
            newArr[i] = arr[i];
        }

        arr = newArr;
        capacity = newCapacity;
    }

    // ================= CORE OPERATIONS =================

    // PUSH
    public void push(int data) {
        if (isFull()) {
            resize(); // 🔥 dynamic growth
        }

        arr[++top] = data;
    }

    // POP
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        }

        int value = arr[top--];

        // Optional shrink (when 1/4 full)
        if (size() > 0 && size() <= capacity / 4) {
            shrink();
        }

        return value;
    }

    // PEEK
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }

        return arr[top];
    }

    // ================= EXTRA =================

    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }

        System.out.print("Stack (top → bottom): ");

        for (int i = top; i >= 0; i--) {
            System.out.print(arr[i] + " ");
        }

        System.out.println();
    }

    public boolean search(int key) {
        for (int i = 0; i <= top; i++) {
            if (arr[i] == key) return true;
        }
        return false;
    }

    public void clear() {
        arr = new int[capacity];
        top = -1;
    }

    public int get(int index) {
        if (index < 0 || index > top) {
            throw new IndexOutOfBoundsException();
        }
        return arr[index];
    }
}
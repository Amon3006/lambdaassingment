public class CircularDoublyLinkedList {

    // Node class
    class Node {
        int data;
        Node next, prev;

        Node(int data) {
            this.data = data;
        }
    }

    private Node head;
    private Node tail;
    private int size;

    // ================= BASIC =================
    public boolean isEmpty() { return head == null; }
    public boolean isFull() { return false; }
    public int size() { return size; }

    // ================= ADD =================
    public void addFirst(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = tail = newNode;
            head.next = head.prev = head;
        } else {
            newNode.next = head;
            newNode.prev = tail;

            head.prev = newNode;
            tail.next = newNode;

            head = newNode;
        }
        size++;
    }

    public void addLast(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = tail = newNode;
            head.next = head.prev = head;
        } else {
            newNode.prev = tail;
            newNode.next = head;

            tail.next = newNode;
            head.prev = newNode;

            tail = newNode;
        }
        size++;
    }

    public void addAtIndex(int index, int data) {
        if (index < 0 || index > size) {
            System.out.println("Invalid Index");
            return;
        }

        if (index == 0) { addFirst(data); return; }
        if (index == size) { addLast(data); return; }

        Node temp = head;
        for (int i = 0; i < index; i++) temp = temp.next;

        Node newNode = new Node(data);

        newNode.prev = temp.prev;
        newNode.next = temp;

        temp.prev.next = newNode;
        temp.prev = newNode;

        size++;
    }

    // ================= DELETE =================
    public void deleteFirst() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        if (head == tail) {
            head = tail = null;
        } else {
            head = head.next;

            head.prev = tail;
            tail.next = head;
        }
        size--;
    }

    public void deleteLast() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        if (head == tail) {
            head = tail = null;
        } else {
            tail = tail.prev;

            tail.next = head;
            head.prev = tail;
        }
        size--;
    }

    public void deleteAtIndex(int index) {
        if (index < 0 || index >= size) {
            System.out.println("Invalid Index");
            return;
        }

        if (index == 0) { deleteFirst(); return; }
        if (index == size - 1) { deleteLast(); return; }

        Node temp = head;
        for (int i = 0; i < index; i++) temp = temp.next;

        temp.prev.next = temp.next;
        temp.next.prev = temp.prev;

        size--;
    }

    public void deleteAll() {
        head = tail = null;
        size = 0;
    }

    // 🔥 Delete All Occurrences
    public void deleteAllOccurrences(int key) {
        if (isEmpty()) return;

        Node current = head;
        int count = size;

        for (int i = 0; i < count; i++) {
            Node nextNode = current.next;

            if (current.data == key) {

                if (current == head) {
                    deleteFirst();
                } else if (current == tail) {
                    deleteLast();
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                    size--;
                }
            }

            current = nextNode;
            if (isEmpty()) break;
        }
    }

    // ================= DISPLAY =================
    public void displayForward() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        Node temp = head;

        do {
            System.out.print(temp.data + " <-> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println("(back to head)");
    }

    public void displayBackward() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        Node temp = tail;

        do {
            System.out.print(temp.data + " <-> ");
            temp = temp.prev;
        } while (temp != tail);

        System.out.println("(back to tail)");
    }

    // ================= UTILITY =================
    public boolean search(int key) {
        if (isEmpty()) return false;

        Node temp = head;

        do {
            if (temp.data == key) return true;
            temp = temp.next;
        } while (temp != head);

        return false;
    }

    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }

        Node temp = head;
        for (int i = 0; i < index; i++) temp = temp.next;

        return temp.data;
    }

    // 🔥 Reverse CDLL
    public void reverse() {
        if (head == null || head.next == head) return;

        Node current = head;
        Node temp = null;

        do {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        } while (current != head);

        temp = head;
        head = tail;
        tail = temp;
    }
}
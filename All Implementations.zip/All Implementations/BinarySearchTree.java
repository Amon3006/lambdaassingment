public class BinarySearchTree {

    // Node class
    class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    // ================= BASIC =================
    public boolean isEmpty() {
        return root == null;
    }

    // ================= INSERT =================
    public void insert(int data) {
        root = insertRec(root, data);
    }

    private Node insertRec(Node root, int data) {
        if (root == null) {
            return new Node(data);
        }

        if (data < root.data) {
            root.left = insertRec(root.left, data);
        } else if (data > root.data) {
            root.right = insertRec(root.right, data);
        }

        return root;
    }

    // ================= SEARCH =================
    public boolean search(int key) {
        return searchRec(root, key);
    }

    private boolean searchRec(Node root, int key) {
        if (root == null) return false;

        if (key == root.data) return true;

        if (key < root.data)
            return searchRec(root.left, key);
        else
            return searchRec(root.right, key);
    }

    // ================= DELETE =================
    public void delete(int key) {
        root = deleteRec(root, key);
    }

    private Node deleteRec(Node root, int key) {
        if (root == null) return null;

        if (key < root.data) {
            root.left = deleteRec(root.left, key);
        } else if (key > root.data) {
            root.right = deleteRec(root.right, key);
        } else {
            // Node found

            // Case 1: No child
            if (root.left == null && root.right == null) {
                return null;
            }

            // Case 2: One child
            else if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Case 3: Two children
            Node successor = findMinNode(root.right);
            root.data = successor.data;
            root.right = deleteRec(root.right, successor.data);
        }

        return root;
    }

    // ================= FIND MIN/MAX =================

    public int findMin() {
        Node temp = root;
        while (temp.left != null) {
            temp = temp.left;
        }
        return temp.data;
    }

    public int findMax() {
        Node temp = root;
        while (temp.right != null) {
            temp = temp.right;
        }
        return temp.data;
    }

    private Node findMinNode(Node root) {
        while (root.left != null) {
            root = root.left;
        }
        return root;
    }

    // ================= TRAVERSALS =================

    // Inorder (sorted output)
    public void inorder(Node root) {
        if (root == null) return;

        inorder(root.left);
        System.out.print(root.data + " ");
        inorder(root.right);
    }

    public void preorder(Node root) {
        if (root == null) return;

        System.out.print(root.data + " ");
        preorder(root.left);
        preorder(root.right);
    }

    public void postorder(Node root) {
        if (root == null) return;

        postorder(root.left);
        postorder(root.right);
        System.out.print(root.data + " ");
    }

    // ================= SIZE =================
    public int size(Node root) {
        if (root == null) return 0;
        return 1 + size(root.left) + size(root.right);
    }

    // ================= HEIGHT =================
    public int height(Node root) {
        if (root == null) return -1;

        return 1 + Math.max(height(root.left), height(root.right));
    }

    // ================= VALIDATE BST =================
    public boolean isBST() {
        return isBSTUtil(root, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private boolean isBSTUtil(Node root, int min, int max) {
        if (root == null) return true;

        if (root.data <= min || root.data >= max) return false;

        return isBSTUtil(root.left, min, root.data) &&
               isBSTUtil(root.right, root.data, max);
    }

    // ================= LCA =================
    public Node lowestCommonAncestor(Node root, int n1, int n2) {
        if (root == null) return null;

        if (n1 < root.data && n2 < root.data)
            return lowestCommonAncestor(root.left, n1, n2);

        if (n1 > root.data && n2 > root.data)
            return lowestCommonAncestor(root.right, n1, n2);

        return root;
    }

    // ================= CLEAR =================
    public void clear() {
        root = null;
    }

    // Getter
    public Node getRoot() {
        return root;
    }
}
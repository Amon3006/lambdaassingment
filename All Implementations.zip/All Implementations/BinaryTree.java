import java.util.*;

public class BinaryTree {

    // Node class
    static class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    // ================= BASIC =================

    public boolean isEmpty() {
        return root == null;
    }

    // ================= INSERT =================
    // Level order insertion
    public void insert(int data) {
        Node newNode = new Node(data);

        if (root == null) {
            root = newNode;
            return;
        }

        Queue<Node> q = new LinkedList<>();
        q.add(root);

        while (!q.isEmpty()) {
            Node temp = q.remove();

            if (temp.left == null) {
                temp.left = newNode;
                return;
            } else q.add(temp.left);

            if (temp.right == null) {
                temp.right = newNode;
                return;
            } else q.add(temp.right);
        }
    }

    // ================= TRAVERSALS =================

    // Preorder
    public void preorder(Node node) {
        if (node == null) return;

        System.out.print(node.data + " ");
        preorder(node.left);
        preorder(node.right);
    }

    // Inorder
    public void inorder(Node node) {
        if (node == null) return;

        inorder(node.left);
        System.out.print(node.data + " ");
        inorder(node.right);
    }

    // Postorder
    public void postorder(Node node) {
        if (node == null) return;

        postorder(node.left);
        postorder(node.right);
        System.out.print(node.data + " ");
    }

    // Level Order
    public void levelOrder() {
        if (root == null) return;

        Queue<Node> q = new LinkedList<>();
        q.add(root);

        while (!q.isEmpty()) {
            Node temp = q.remove();
            System.out.print(temp.data + " ");

            if (temp.left != null) q.add(temp.left);
            if (temp.right != null) q.add(temp.right);
        }
    }

    // ================= SEARCH =================

    public boolean search(int key) {
        if (root == null) return false;

        Queue<Node> q = new LinkedList<>();
        q.add(root);

        while (!q.isEmpty()) {
            Node temp = q.remove();

            if (temp.data == key) return true;

            if (temp.left != null) q.add(temp.left);
            if (temp.right != null) q.add(temp.right);
        }

        return false;
    }

    // ================= SIZE =================

    public int size(Node node) {
        if (node == null) return 0;
        return 1 + size(node.left) + size(node.right);
    }

    // ================= HEIGHT =================

    public int height(Node node) {
        if (node == null) return -1;

        return 1 + Math.max(height(node.left), height(node.right));
    }

    // ================= DELETE =================
    // Delete deepest node logic
    public void delete(int key) {
        if (root == null) return;

        if (root.left == null && root.right == null) {
            if (root.data == key) root = null;
            return;
        }

        Queue<Node> q = new LinkedList<>();
        q.add(root);

        Node keyNode = null, temp = null;

        while (!q.isEmpty()) {
            temp = q.remove();

            if (temp.data == key) keyNode = temp;

            if (temp.left != null) q.add(temp.left);
            if (temp.right != null) q.add(temp.right);
        }

        if (keyNode != null) {
            int x = temp.data; // deepest node
            deleteDeepest(temp);
            keyNode.data = x;
        }
    }

    private void deleteDeepest(Node delNode) {
        Queue<Node> q = new LinkedList<>();
        q.add(root);

        while (!q.isEmpty()) {
            Node temp = q.remove();

            if (temp.left == delNode) {
                temp.left = null;
                return;
            } else if (temp.left != null) q.add(temp.left);

            if (temp.right == delNode) {
                temp.right = null;
                return;
            } else if (temp.right != null) q.add(temp.right);
        }
    }

    // ================= MIN / MAX =================

    public int findMin(Node node) {
        if (node == null) return Integer.MAX_VALUE;
        return Math.min(node.data, Math.min(findMin(node.left), findMin(node.right)));
    }

    public int findMax(Node node) {
        if (node == null) return Integer.MIN_VALUE;
        return Math.max(node.data, Math.max(findMax(node.left), findMax(node.right)));
    }

    // ================= COUNT LEAF =================

    public int countLeaf(Node node) {
        if (node == null) return 0;

        if (node.left == null && node.right == null) return 1;

        return countLeaf(node.left) + countLeaf(node.right);
    }

    // ================= CLEAR =================

    public void clear() {
        root = null;
    }

    // Getter for root (for traversal calls)
    public Node getRoot() {
        return root;
    }
}
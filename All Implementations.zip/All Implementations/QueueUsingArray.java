public class QueueUsingArray {
    private int[] arr;
    private int front;
    private int rear;
    private int capacity;

    // Constructor
    public QueueUsingArray(int size) {
        capacity = size;
        arr = new int[size];
        front = 0;
        rear = -1;
    }

    // ================= BASIC =================

    public boolean isEmpty() {
        return front > rear;
    }

    public boolean isFull() {
        return rear == capacity - 1;
    }

    public int size() {
        if (isEmpty()) return 0;
        return rear - front + 1;
    }

    // ================= CORE =================

    // ENQUEUE
    public void enqueue(int data) {
        if (isFull()) {
            System.out.println("Queue Overflow");
            return;
        }

        arr[++rear] = data;
    }

    // DEQUEUE
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow");
            return -1;
        }

        return arr[front++];
    }

    // FRONT (peek)
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }

        return arr[front];
    }

    // REAR element
    public int getRear() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }

        return arr[rear];
    }

    // ================= EXTRA =================

    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }

        System.out.print("Queue (front → rear): ");

        for (int i = front; i <= rear; i++) {
            System.out.print(arr[i] + " ");
        }

        System.out.println();
    }

    public boolean search(int key) {
        for (int i = front; i <= rear; i++) {
            if (arr[i] == key) return true;
        }
        return false;
    }

    public void clear() {
        front = 0;
        rear = -1;
    }

    public int get(int index) {
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException();
        }

        return arr[front + index];
    }
}
public class CircularLinkedList {

    // Node class
    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    private Node head;
    private Node tail;
    private int size;

    // ================= BASIC =================
    public boolean isEmpty() { return head == null; }
    public boolean isFull() { return false; }

    public int size() { return size; }

    // ================= ADD =================
    public void addFirst(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = tail = newNode;
            tail.next = head;
        } else {
            newNode.next = head;
            head = newNode;
            tail.next = head;
        }
        size++;
    }

    public void addLast(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = tail = newNode;
            tail.next = head;
        } else {
            tail.next = newNode;
            tail = newNode;
            tail.next = head;
        }
        size++;
    }

    public void addAtIndex(int index, int data) {
        if (index < 0 || index > size) {
            System.out.println("Invalid Index");
            return;
        }

        if (index == 0) { addFirst(data); return; }
        if (index == size) { addLast(data); return; }

        Node newNode = new Node(data);
        Node temp = head;

        for (int i = 0; i < index - 1; i++) {
            temp = temp.next;
        }

        newNode.next = temp.next;
        temp.next = newNode;
        size++;
    }

    // ================= DELETE =================
    public void deleteFirst() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        if (head == tail) {
            head = tail = null;
        } else {
            head = head.next;
            tail.next = head;
        }
        size--;
    }

    public void deleteLast() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        if (head == tail) {
            head = tail = null;
        } else {
            Node temp = head;

            while (temp.next != tail) {
                temp = temp.next;
            }

            temp.next = head;
            tail = temp;
        }
        size--;
    }

    public void deleteAtIndex(int index) {
        if (index < 0 || index >= size) {
            System.out.println("Invalid Index");
            return;
        }

        if (index == 0) { deleteFirst(); return; }
        if (index == size - 1) { deleteLast(); return; }

        Node temp = head;

        for (int i = 0; i < index - 1; i++) {
            temp = temp.next;
        }

        temp.next = temp.next.next;
        size--;
    }

    public void deleteAll() {
        head = tail = null;
        size = 0;
    }

    // 🔥 Delete All Occurrences
    public void deleteAllOccurrences(int key) {
        if (isEmpty()) return;

        // Remove from head
        while (head != null && head.data == key) {
            deleteFirst();
            if (head == null) return;
        }

        Node current = head;

        do {
            Node nextNode = current.next;

            if (nextNode != head && nextNode.data == key) {
                if (nextNode == tail) {
                    deleteLast();
                } else {
                    current.next = nextNode.next;
                    size--;
                }
            } else {
                current = current.next;
            }

        } while (current.next != head);
    }

    // ================= UTILITY =================
    public void display() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        Node temp = head;

        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println("(back to head)");
    }

    public boolean search(int key) {
        if (isEmpty()) return false;

        Node temp = head;

        do {
            if (temp.data == key) return true;
            temp = temp.next;
        } while (temp != head);

        return false;
    }

    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }

        Node temp = head;

        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }

        return temp.data;
    }

    // 🔥 Reverse CLL
    public void reverse() {
        if (head == null || head.next == head) return;

        Node prev = null;
        Node curr = head;
        Node next;
        Node start = head;

        do {
            next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        } while (curr != start);

        head.next = prev;
        tail = head;
        head = prev;
    }
}
public class StackLinkedList {

    // Node class
    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    private Node top;
    private int size;

    // ================= BASIC =================
    public boolean isEmpty() {
        return top == null;
    }

    public boolean isFull() {
        return false; // Dynamic structure
    }

    public int size() {
        return size;
    }

    // ================= CORE OPERATIONS =================

    // PUSH
    public void push(int data) {
        Node newNode = new Node(data);

        newNode.next = top;
        top = newNode;
        size++;
    }

    // POP
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        }

        int value = top.data;
        top = top.next;
        size--;

        return value;
    }

    // PEEK
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }

        return top.data;
    }

    // ================= EXTRA OPERATIONS =================

    // Display
    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }

        Node temp = top;

        System.out.print("Stack (top → bottom): ");

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }

        System.out.println();
    }

    // Search
    public boolean search(int key) {
        Node temp = top;

        while (temp != null) {
            if (temp.data == key) return true;
            temp = temp.next;
        }
        return false;
    }

    // Clear stack
    public void clear() {
        top = null;
        size = 0;
    }

    // Get element at position (0 = top)
    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }

        Node temp = top;

        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }

        return temp.data;
    }
}
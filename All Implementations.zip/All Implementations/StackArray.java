public class StackArray {

    private int[] arr;
    private int top;
    private int capacity;

    // Constructor
    public StackArray(int size) {
        arr = new int[size];
        capacity = size;
        top = -1;
    }

    // ================= BASIC =================

    // isEmpty
    public boolean isEmpty() {
        return top == -1;
    }

    // isFull
    public boolean isFull() {
        return top == capacity - 1;
    }

    // size
    public int size() {
        return top + 1;
    }

    // ================= CORE OPERATIONS =================

    // PUSH
    public void push(int data) {
        if (isFull()) {
            System.out.println("Stack Overflow");
            return;
        }

        arr[++top] = data;
    }

    // POP
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        }

        return arr[top--];
    }

    // PEEK (Top element)
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }

        return arr[top];
    }

    // ================= EXTRA OPERATIONS =================

    // Display stack
    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }

        System.out.print("Stack (top → bottom): ");

        for (int i = top; i >= 0; i--) {
            System.out.print(arr[i] + " ");
        }

        System.out.println();
    }

    // Search element
    public boolean search(int key) {
        for (int i = 0; i <= top; i++) {
            if (arr[i] == key) return true;
        }
        return false;
    }

    // Clear stack
    public void clear() {
        top = -1;
    }

    // Get element at index (optional)
    public int get(int index) {
        if (index < 0 || index > top) {
            throw new IndexOutOfBoundsException();
        }
        return arr[index];
    }
}
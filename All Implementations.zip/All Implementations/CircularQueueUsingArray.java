public class CircularQueueUsingArray {

    private int[] arr;
    private int front;
    private int rear;
    private int capacity;

    // Constructor
    public CircularQueueUsingArray(int size) {
        capacity = size;
        arr = new int[size];
        front = -1;
        rear = -1;
    }

    // ================= BASIC =================

    public boolean isEmpty() {
        return front == -1;
    }

    public boolean isFull() {
        return (rear + 1) % capacity == front;
    }

    public int size() {
        if (isEmpty()) return 0;
        if (rear >= front) return rear - front + 1;
        return capacity - front + rear + 1;
    }

    // ================= CORE =================

    // ENQUEUE
    public void enqueue(int data) {
        if (isFull()) {
            System.out.println("Queue Overflow");
            return;
        }

        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % capacity;
        }

        arr[rear] = data;
    }

    // DEQUEUE
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow");
            return -1;
        }

        int value = arr[front];

        if (front == rear) {
            front = rear = -1; // last element removed
        } else {
            front = (front + 1) % capacity;
        }

        return value;
    }

    // PEEK (Front)
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }

        return arr[front];
    }

    // REAR element
    public int getRear() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }

        return arr[rear];
    }

    // ================= EXTRA =================

    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }

        System.out.print("Queue (front → rear): ");

        int i = front;
        while (true) {
            System.out.print(arr[i] + " ");
            if (i == rear) break;
            i = (i + 1) % capacity;
        }

        System.out.println();
    }

    public boolean search(int key) {
        if (isEmpty()) return false;

        int i = front;
        while (true) {
            if (arr[i] == key) return true;
            if (i == rear) break;
            i = (i + 1) % capacity;
        }

        return false;
    }

    public void clear() {
        front = rear = -1;
    }

    public int get(int index) {
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException();
        }

        return arr[(front + index) % capacity];
    }
}
import java.util.LinkedList;
import java.util.Queue;

public class StackUsingQueues {

    private Queue<Integer> q1;
    private Queue<Integer> q2;

    public StackUsingQueues() {
        q1 = new LinkedList<>();
        q2 = new LinkedList<>();
    }

    // ================= BASIC =================

    public boolean isEmpty() {
        return q1.isEmpty();
    }

    public int size() {
        return q1.size();
    }

    // ================= CORE =================

    // PUSH (costly)
    public void push(int x) {

        // Step 1: Add to q2
        q2.add(x);

        // Step 2: Move all elements of q1 to q2
        while (!q1.isEmpty()) {
            q2.add(q1.remove());
        }

        // Step 3: Swap q1 and q2
        Queue<Integer> temp = q1;
        q1 = q2;
        q2 = temp;
    }

    // POP (easy)
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        }
        return q1.remove();
    }

    // PEEK
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }
        return q1.peek();
    }

    // ================= EXTRA =================

    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }

        System.out.print("Stack (top → bottom): ");

        for (int x : q1) {
            System.out.print(x + " ");
        }

        System.out.println();
    }

    public boolean search(int key) {
        return q1.contains(key);
    }

    public void clear() {
        q1.clear();
        q2.clear();
    }
}
class SinglyLinkedList {

    // Node class
    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;
    private int size;

    // Constructor
    public SinglyLinkedList() {
        head = null;
        size = 0;
    }

    // 1. isEmpty()
    public boolean isEmpty() {
        return head == null;
    }

    // 2. isFull() (Not applicable in LL, but for formality)
    public boolean isFull() {
        return false; // LinkedList grows dynamically
    }

    // 3. Add First
    public void addFirst(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
        size++;
    }

    // 4. Add Last
    public void addLast(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        size++;
    }

    // 5. Add at Index
    public void addAtIndex(int index, int data) {
        if (index < 0 || index > size) {
            System.out.println("Invalid Index");
            return;
        }

        if (index == 0) {
            addFirst(data);
            return;
        }

        Node newNode = new Node(data);
        Node temp = head;

        for (int i = 0; i < index - 1; i++) {
            temp = temp.next;
        }

        newNode.next = temp.next;
        temp.next = newNode;
        size++;
    }

    // 6. Delete First
    public void deleteFirst() {
    if (isEmpty()) {
        System.out.println("List is empty");
        return;
    }

    if (head.next==null) { 
        head = null;
    } else {
        head = head.next;
    }

    size--;
}

    // 7. Delete Last
    public void deleteLast() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        if (head.next == null) {
            head = null;
        } else {
            Node temp = head;

            while (temp.next.next != null) {
                temp = temp.next;
            }

            temp.next = null;
        }
        size--;
    }

    // 8. Delete at Index
    public void deleteAtIndex(int index) {
        if (index < 0 || index >= size) {
            System.out.println("Invalid Index");
            return;
        }

        if (index == 0) {
            deleteFirst();
            return;
        }

        Node temp = head;

        for (int i = 0; i < index - 1; i++) {
            temp = temp.next;
        }

        temp.next = temp.next.next;
        size--;
    }

    // 9. Delete All
    public void deleteAll() {
        head = null;
        size = 0;
    }

    // 10. Display List
    public void display() {
        Node temp = head;

        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }
        System.out.println("null");
    }

    // 11. Get Size
    public int size() {
        return size;
    }

    // 12. Search Element
    public boolean search(int key) {
        Node temp = head;

        while (temp != null) {
            if (temp.data == key) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    // 13. Get Element at Index
    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }

        Node temp = head;

        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }

        return temp.data;
    }

    // 14. Reverse Linked List
    public void reverse() {
        Node prev = null;
        Node curr = head;
        Node next;

        while (curr != null) {
            next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }

        head = prev;
    }

    // 15. Delete all occurence of element
    public void deleteAllOccurrences(int key) {

    // 1. Remove matching elements from beginning
    while (head != null && head.data == key) {
        head = head.next;
        size--;
    }

    // 2. Traverse remaining list
    Node current = head;

    while (current != null && current.next != null) {
        if (current.next.data == key) {
            current.next = current.next.next;
            size--;
        } else {
            current = current.next;
        }
    }
}
}
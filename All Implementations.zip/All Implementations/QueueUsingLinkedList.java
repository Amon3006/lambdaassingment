public class QueueUsingLinkedList {

    // Node class
    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    private Node front;
    private Node rear;
    private int size;

    // ================= BASIC =================

    public boolean isEmpty() {
        return front == null;
    }

    public boolean isFull() {
        return false; // Dynamic structure
    }

    public int size() {
        return size;
    }

    // ================= CORE OPERATIONS =================

    // ENQUEUE
    public void enqueue(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }

        size++;
    }

    // DEQUEUE
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow");
            return -1;
        }

        int value = front.data;
        front = front.next;

        // If queue becomes empty
        if (front == null) {
            rear = null;
        }

        size--;
        return value;
    }

    // PEEK (Front)
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }

        return front.data;
    }

    // REAR element
    public int getRear() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }

        return rear.data;
    }

    // ================= EXTRA OPERATIONS =================

    // Display
    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }

        Node temp = front;

        System.out.print("Queue (front → rear): ");

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }

        System.out.println();
    }

    // Search
    public boolean search(int key) {
        Node temp = front;

        while (temp != null) {
            if (temp.data == key) return true;
            temp = temp.next;
        }
        return false;
    }

    // Clear
    public void clear() {
        front = rear = null;
        size = 0;
    }

    // Get element at index (relative to front)
    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }

        Node temp = front;

        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }

        return temp.data;
    }
}